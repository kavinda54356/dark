# Calculator with GUI using Python

This repository contains the code for a calculator with a graphical user interface (GUI) implemented in Python.

To run the application, you will need the following software:
- Python 3
- Tkinter library

To run the application, execute the following command:
$ python calculator.py
